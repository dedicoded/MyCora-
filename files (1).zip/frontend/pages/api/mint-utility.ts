import type { NextApiRequest, NextApiResponse } from 'next';
import { utilityToken } from '../../../backend/server';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { walletAddress, metadataURI } = req.body;
      const tx = await utilityToken.mint(walletAddress, metadataURI);
      res.status(200).json({ txHash: tx.hash });
    } catch (err) {
      res.status(500).send(err.message);
    }
  } else {
    res.status(405).end();
  }
}