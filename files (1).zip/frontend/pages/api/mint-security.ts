import type { NextApiRequest, NextApiResponse } from 'next';
import { securityToken } from '../../../backend/server';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { walletAddress, amount } = req.body;
      const whitelisted = await securityToken.isWhitelisted(walletAddress);
      if (!whitelisted) return res.status(403).send('User not whitelisted');
      const tx = await securityToken.mint(walletAddress, amount);
      res.status(200).json({ txHash: tx.hash });
    } catch (err) {
      res.status(500).send(err.message);
    }
  } else {
    res.status(405).end();
  }
}