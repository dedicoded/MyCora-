import type { NextApiRequest, NextApiResponse } from 'next';
import { uploadMetadata } from '../../../backend/upload';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const uri = await uploadMetadata(req.body);
      res.status(200).json({ uri });
    } catch (err) {
      res.status(500).send(err.message);
    }
  } else {
    res.status(405).end();
  }
}