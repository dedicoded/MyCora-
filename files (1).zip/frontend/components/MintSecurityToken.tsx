import { useState } from 'react';
import { useAccount } from 'wagmi';

export default function MintSecurityToken() {
  const { address } = useAccount();
  const [amount, setAmount] = useState('');
  const [status, setStatus] = useState('');

  const handleMint = async () => {
    const resMint = await fetch('/api/mint-security', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ walletAddress: address, amount }),
    });

    if (resMint.status === 403) {
      setStatus('Not whitelisted for minting.');
      return;
    }

    const data = await resMint.json();
    setStatus(`Minted! Tx: ${data.txHash}`);
  };

  return (
    <div>
      <h2>Mint Security Token</h2>
      <input placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
      <button onClick={handleMint}>Mint</button>
      <p>{status}</p>
    </div>
  );
}