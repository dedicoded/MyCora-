import { useState } from 'react';
import { useAccount } from 'wagmi';

export default function MintUtilityToken() {
  const { address } = useAccount();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [imageURL, setImageURL] = useState('');
  const [status, setStatus] = useState('');

  const handleMint = async () => {
    const metadata = { name, description, image: imageURL };
    const resUpload = await fetch('/api/upload-metadata', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(metadata),
    });
    const { uri } = await resUpload.json();

    const resMint = await fetch('/api/mint-utility', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ walletAddress: address, metadataURI: uri }),
    });

    const data = await resMint.json();
    setStatus(`Minted! Tx: ${data.txHash}`);
  };

  return (
    <div>
      <h2>Mint Utility Token</h2>
      <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
      <input placeholder="Description" value={description} onChange={e => setDescription(e.target.value)} />
      <input placeholder="Image URL" value={imageURL} onChange={e => setImageURL(e.target.value)} />
      <button onClick={handleMint}>Upload & Mint</button>
      <p>{status}</p>
    </div>
  );
}