import express from 'express';
import bodyParser from 'body-parser';
import { ethers } from 'ethers';
import cors from 'cors';
import dotenv from 'dotenv';
import { uploadMetadata } from './upload.js';

import SECURITY_ABI from './SECURITY_ABI.json' assert { type: "json" };
import UTILITY_ABI from './UTILITY_ABI.json' assert { type: "json" };

dotenv.config();
const app = express();
app.use(cors());
app.use(bodyParser.json());

const provider = new ethers.JsonRpcProvider(process.env.ALCHEMY_RPC_URL);
const signer = new ethers.Wallet(process.env.PRIVATE_KEY, provider);

const securityToken = new ethers.Contract(
  process.env.SECURITY_TOKEN_ADDRESS,
  SECURITY_ABI,
  signer
);

const utilityToken = new ethers.Contract(
  process.env.UTILITY_TOKEN_ADDRESS,
  UTILITY_ABI,
  signer
);

// Whitelist an address
app.post('/whitelist', async (req, res) => {
  const { walletAddress } = req.body;
  try {
    const tx = await securityToken.whitelist(walletAddress);
    res.json({ txHash: tx.hash });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Mint Security Token
app.post('/mint-security', async (req, res) => {
  const { walletAddress, amount } = req.body;
  try {
    const whitelisted = await securityToken.isWhitelisted(walletAddress);
    if (!whitelisted) return res.status(403).send('User not whitelisted');
    const tx = await securityToken.mint(walletAddress, amount);
    res.json({ txHash: tx.hash });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Upload metadata to IPFS
app.post('/upload-metadata', async (req, res) => {
  try {
    const uri = await uploadMetadata(req.body);
    res.json({ uri });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Mint Utility Token
app.post('/mint-utility', async (req, res) => {
  const { walletAddress, metadataURI } = req.body;
  try {
    const tx = await utilityToken.mint(walletAddress, metadataURI);
    res.json({ txHash: tx.hash });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.listen(3000, () => console.log('MyCora backend running on port 3000'));