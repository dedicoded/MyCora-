# MyCora Mint Backend

## Features
- Upload document, push to IPFS
- Create metadata (name, description, doc link), push to IPFS
- Mint ERC-721 trust-wrapped token with metadata URI
- All via `/mint` POST API

## Usage

1. Fill `.env` with contract, RPC, and IPFS credentials.
2. `npm install express multer ipfs-http-client ethers cors`
3. Start server: `node server.js`

### Mint API Example

**POST /mint**  
FormData fields:  
- document: (file)
- name: (string)
- description: (string)
- walletAddress: (string)

Response:
```json
{
  "success": true,
  "txHash": "0x...",
  "metadataURI": "https://ipfs.io/ipfs/...",
  "documentURI": "https://ipfs.io/ipfs/..."
}
```

## Security
- Never expose PRIVATE_KEY publicly.
- Use Replit secrets for environment vars.

## Frontend
- Use FormData and POST `/mint`
- Get `txHash` and token metadata to show in dashboard.