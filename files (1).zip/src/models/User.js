import mongoose from 'mongoose';

const UserSchema = new mongoose.Schema({
  walletAddress: { type: String, required: true, unique: true },
  email: String,
  role: { type: String, default: 'individual' },
  trustScore: { type: Number, default: 0 },
  patents: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Patent' }],
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model('User', UserSchema);