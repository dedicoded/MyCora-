import mongoose from 'mongoose';

const PatentSchema = new mongoose.Schema({
  title: String,
  description: String,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  metadataURI: String,
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model('Patent', PatentSchema);