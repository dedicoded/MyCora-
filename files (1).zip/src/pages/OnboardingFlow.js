export default function OnboardingFlow() {
  return (
    <section className="max-w-xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Onboarding</h2>
      <p className="mb-4">Connect your wallet, complete payment, and root yourself into the network!</p>
      {/* WalletConnect, Payment Integration, etc. */}
    </section>
  );
}