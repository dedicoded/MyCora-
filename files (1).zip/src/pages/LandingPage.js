export default function LandingPage() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-gray-900 to-green-900">
      <h2 className="text-4xl font-semibold text-white my-8">Welcome to MyCora</h2>
      <p className="text-lg text-gray-300 max-w-md text-center">
        Grow your trust, explore patents, and connect your payments in a living, mycelial blockchain network.
      </p>
      <a href="/onboarding" className="mt-12 bg-green-700 hover:bg-green-800 text-white px-6 py-3 rounded-full transition">Get Started</a>
    </main>
  );
}