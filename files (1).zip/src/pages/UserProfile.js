export default function UserProfile() {
  return (
    <section className="max-w-2xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Profile</h2>
      {/* TrustBadges, GrowthJourney */}
    </section>
  );
}