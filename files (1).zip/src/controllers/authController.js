import User from '../models/User';
import jwt from 'jsonwebtoken';

export async function login(req, res) {
  const { walletAddress } = req.body;
  let user = await User.findOne({ walletAddress });
  if (!user) {
    user = await User.create({ walletAddress });
  }
  const token = jwt.sign({ id: user._id, walletAddress }, process.env.JWT_SECRET);
  res.json({ token, user });
}