export default function Header() {
  return (
    <header className="bg-gradient-to-r from-green-900 via-gray-900 to-purple-900 p-4 text-white flex justify-between items-center">
      <h1 className="font-bold text-2xl">MyCora</h1>
      <nav>
        <a href="/" className="mx-2">Home</a>
        <a href="/dashboard" className="mx-2">Dashboard</a>
        <a href="/patents" className="mx-2">Patents</a>
        <a href="/community" className="mx-2">Community</a>
        <a href="/profile" className="mx-2">Profile</a>
        <a href="/settings" className="mx-2">Settings</a>
      </nav>
    </header>
  );
}