import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import OnboardingFlow from './pages/OnboardingFlow';
import Dashboard from './pages/Dashboard';
import PatentExplorer from './pages/PatentExplorer';
import CommunityGarden from './pages/CommunityGarden';
import UserProfile from './pages/UserProfile';
import Settings from './pages/Settings';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <Header />
      <Switch>
        <Route exact path="/" component={LandingPage} />
        <Route path="/onboarding" component={OnboardingFlow} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/patents" component={PatentExplorer} />
        <Route path="/community" component={CommunityGarden} />
        <Route path="/profile" component={UserProfile} />
        <Route path="/settings" component={Settings} />
      </Switch>
      <Footer />
    </Router>
  );
}

export default App;