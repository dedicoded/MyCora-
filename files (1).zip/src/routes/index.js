import { Router } from 'express';
import authRoutes from './auth';
import patentRoutes from './patents';
import trustRoutes from './trust';
import paymentRoutes from './payments';

const router = Router();

router.use('/auth', authRoutes);
router.use('/patents', patentRoutes);
router.use('/trust', trustRoutes);
router.use('/payments', paymentRoutes);

export default router;